﻿# RenalPlan CoFID 2021 recipe audit — read-only baseline

**Prepared:** 15 October 2026  
**Project inspected:** `C:\Users\rj-jo\OneDrive\Documents\RenalPlan`  
**Status:** Baseline and proposed plan only. No recipe data or application code was changed.

## Active data

The active dataset is assembled by `data/RecipeData/index.ts`: 50 breakfasts, 48 lunches and 52 dinners. It contains 150 unique recipes and 857 ingredient lines. Every recipe currently has one serving. Recipe data includes ingredients, shopping names/quantities, instructions, time, image, description, dietary levels, nutrition values and fluid estimate. It has no allergen or tags fields. Top-level calories/protein duplicate the nested nutrition values and currently match.

Recipe nutrition totals are stored in the dataset rather than calculated from ingredients at runtime. The app parses and sums stored values for meal/day/week views. Planner IDs are used by saved plans and favourites; shopping quantities are calculated separately from ingredient quantities and planner people counts. IDs and existing storage fields should remain stable.

## Audit nutrient scope

Fibre is excluded from this audit’s calculations, completeness metrics, status rules and priorities, as requested. The seven numeric CoFID comparisons are energy, protein, carbohydrate, fat, sodium, potassium and phosphorus. Salt is derived from sodium; purines are qualitative. There are no sugars, saturates or numeric purine fields.

**Repository discrepancy:** RenalPlan currently stores, sums and displays fibre. This package excludes it from audit results only and does not change application behaviour.

## Existing workbook baseline

The included `Existing_CoFID_2021_Audit_Workbook.xlsx` contains Summary, Recipe Status, Nutrient Comparison, Ingredient Audit, Potato K Review, and Method and Sources sheets. It traces all 857 ingredient lines and records CoFID codes and worksheet row references for matched foods.

Its current summary reports 221 exact food-name matches, 572 standardized equivalents, 64 conditional or unmatched profiles and 232 estimated household weights. It reports 15 verified, 10 discrepancies, 125 unresolved, and 73 recipes with all eight numeric comparisons. **These are legacy workbook figures and include fibre. They are not the new fibre-excluded results.** Its ±10% screen is described as QA, not a clinical or regulatory tolerance.

## Confirmed review flags

### Cooking oil

L013, L020, L022, L024, L028 and L029 are flagged. The workbook matches “Vegetable oil” to CoFID code 17-686, with 99.9 g fat per 100 g. A 10 g line contributes about 9.99 g fat; a 15 g line about 14.985 g. Stored total fat for those recipes is 2.9, 6.5, 2.1, 3.4, 2.0 and 9.5 g, each below the oil contribution alone. Their methods do not say to discard oil. Full nutrient recalculation and a documented oil-retention basis are required before correction.

### Potatoes

L028, L029, L030, D023 and D040 are flagged. L028–L030 cut, boil and drain potatoes, while stored potassium is close to the workbook’s raw-input calculation. The workbook records CoFID potassium profiles of 443 mg/100 g for its raw potato match and 365 mg/100 g for peeled, boiled potato. Exact corrections depend on whether recipe grams mean raw input or cooked edible weight.

D023 and D040 store 760 mg and 680 mg potassium. The workbook’s raw-input ingredient subtotals are 1,826.7 mg and 1,552.5 mg; same-gram cooked/drained scenarios are 1,560.7 mg and 1,391.8 mg. These indicate discrepancies but do not establish the weight basis or recipe yield. External cooking-retention studies in the workbook are directional context only, not final CoFID-only values.

## Phosphorus / phosphate recommendation

CoFID reports phosphorus in mg per 100 g. RenalPlan’s field is named `phosphate`, while its requirements page converts mg to mmol using 31 mg/mmol phosphorus, indicating an elemental-phosphorus basis. Retain existing values and thresholds on the CoFID phosphorus basis; do not apply an arbitrary phosphate-ion conversion. For clarity, report “phosphorus (dietary phosphate), mg, CoFID basis” while retaining existing stored keys for compatibility, subject to review before code changes.

## Proposed remediation plan

1. Recalculate baseline and status using the seven numeric nutrients, excluding fibre throughout.
2. Recheck CoFID matches and quantity assumptions; preserve exact/standardized/approximate/uncertain/missing-data distinctions.
3. Investigate all six oil and five potato recipes; correct only where ingredients, methods and weight basis support a defensible value. Keep uncertain cases unresolved and state what evidence is missing.
4. For each confirmed recipe change, check descriptions, instructions, duplicated nutrition fields, derived salt, dietary levels, image suitability, shopping quantities, planner, favourites, MyChef and nutrition summaries. Preserve IDs and storage compatibility.
5. Add regression checks. No test suite or test script was found; existing package scripts include lint and build.
6. Produce a versioned fibre-excluded traceability workbook and change log while preserving the current workbook as baseline.

## Sources

- CoFID 2021: https://www.gov.uk/government/publications/composition-of-foods-integrated-dataset-cofid
- CoFID 2021 User Guide: https://assets.publishing.service.gov.uk/media/60538e66d3bf7f03249bac58/McCance_and_Widdowsons_Composition_of_Foods_integrated_dataset_2021.pdf
- North Bristol NHS Trust renal phosphate information: https://www.nbt.nhs.uk/our-services/a-z-services/nutrition-dietetics/nutrition-dietetics-patient-information-kidney-disease/managing-phosphate-your-diet-information-kidney-patients
